
export default function Home() {
  return (
    <div style={{ padding: 40, fontFamily: 'sans-serif' }}>
      <h1 style={{ fontSize: 32, color: '#0070f3' }}>Welcome to AllSafeTechUK</h1>
      <p style={{ marginTop: 20 }}>This is a placeholder for your site. Custom content will appear here.</p>
    </div>
  )
}
